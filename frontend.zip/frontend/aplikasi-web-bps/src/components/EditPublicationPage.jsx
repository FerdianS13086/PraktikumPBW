import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { usePublications } from '../hooks/usePublications';
import { uploadImageToCloudinary } from '../services/publicationService';

export default function EditPublicationPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { publications, editPublication } = usePublications();

  const publication = publications.find(pub => pub.id === Number(id));

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [releaseDate, setReleaseDate] = useState('');
  const [coverFile, setCoverFile] = useState(null);
  const [oldCoverUrl, setOldCoverUrl] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (publication) {
      setTitle(publication.title);
      setDescription(publication.description || '');
      setReleaseDate(publication.releaseDate);
      setOldCoverUrl(publication.coverUrl);
    }
  }, [publication]);

  if (!publication) {
    return <div className="text-center text-red-600">Publication not found.</div>;
  }

  const validate = () => {
    if (!title.trim()) {
      setError('Judul harus diisi');
      return false;
    }
    if (!releaseDate) {
      setError('Tanggal rilis harus diisi');
      return false;
    }
    setError('');
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    let coverUrl = oldCoverUrl;
    if (coverFile) {
      try {
        coverUrl = await uploadImageToCloudinary(coverFile);
      } catch (err) {
        setError('Gagal upload gambar: ' + err.message);
        return;
      }
    }

    const updatedPublication = {
      id: publication.id,
      title,
      description,
      releaseDate,
      coverUrl,
    };

    try {
      await editPublication(updatedPublication);
      navigate('/publications');
    } catch (err) {
      setError('Gagal mengubah publikasi: ' + err.message);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Edit Publikasi</h1>
      {error && <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-md text-sm">{error}</div>}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">Judul</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={e => setTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500"
            placeholder="Judul publikasi"
            required
          />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
          <textarea
            id="description"
            value={description}
            onChange={e => setDescription(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500"
            placeholder="Deskripsi publikasi"
            rows={4}
          />
        </div>
        <div>
          <label htmlFor="releaseDate" className="block text-sm font-medium text-gray-700 mb-1">Tanggal Rilis</label>
          <input
            type="date"
            id="releaseDate"
            value={releaseDate}
            onChange={e => setReleaseDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Sampul Lama</label>
          <img src={oldCoverUrl} alt="Sampul Lama" className="h-24 w-auto object-cover rounded shadow-md mb-2" />
        </div>
        <div>
          <label htmlFor="coverFile" className="block text-sm font-medium text-gray-700 mb-1">Sampul Baru (Gambar)</label>
          <input
            type="file"
            id="coverFile"
            accept="image/*"
            onChange={e => setCoverFile(e.target.files[0])}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
          />
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            className="bg-sky-700 hover:bg-sky-800 text-white font-bold py-2 px-6 rounded-lg transition-colors duration-300"
          >
            Ubah
          </button>
        </div>
      </form>
    </div>
  );
}
