<?php

include 'dbconn.php';

try
{
    $no = $_POST['no'];
    $judul = $_POST['judul'];
    $tanggal_rilis = $_POST['tanggal_rilis'];

    if (isset($_FILES['sampul_baru']) && $_FILES['sampul_baru']['error'] === 0)
    {
        // Handle new sampul upload
        $namaFile = $_FILES['sampul_baru']['name'];
        $lokasiSementara = $_FILES['sampul_baru']['tmp_name'];

        $dirUpload = 'asset/';

        if (!is_dir($dirUpload))
        {
            mkdir($dirUpload, 0755, true);
        }

        if (!move_uploaded_file($lokasiSementara, $dirUpload . $namaFile))
        {
            exit('Terjadi kesalahan saat mengupload file sampul baru.');
        }

        // Update judul, tanggal_rilis, and sampul
        $sql = "UPDATE publikasi SET judul = :judul, tanggal_rilis = :tanggal_rilis, sampul = :sampul WHERE no = :no";
        $stmt = $pdo -> prepare($sql);
        $stmt -> execute([
            ':judul'  => $judul,
            ':tanggal_rilis'  => $tanggal_rilis,
            ':sampul'  => $namaFile,
            ':no'  => $no
        ]);
    } else
    {
        // Update judul and tanggal_rilis only
        $sql = "UPDATE publikasi SET judul = :judul, tanggal_rilis = :tanggal_rilis WHERE no = :no";
        $stmt = $pdo -> prepare($sql);
        $stmt -> execute([
            ':judul'  => $judul,
            ':tanggal_rilis'  => $tanggal_rilis,
            ':no'  => $no
        ]);
    }

    echo "
        <script>
            alert('Data Berhasil Diupdate');
            window.location.href = 'page09A.php';
        </script>
    ";

    $pdo = NULL;
} catch (PDOException $e)
{
    exit("PDO Error: " . $e -> getMessage() . "<br>");
}