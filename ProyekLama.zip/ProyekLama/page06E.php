<?php
include 'dbconn.php';
?>

<!DOCTYPE html>
<html lang = "id">
<head>
    <meta charset = "UTF-8" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1" />
    <title>Galeri Kegiatan BPS Kalimantan Tengah</title>
    <link rel = "stylesheet" href = "myCSS.css" />
    <style>
        .gallery-container
        {
            width: 75%;
            margin: 20px auto;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }

        .preview
        {
            float: left;
            width: 65%;
            padding: 10px;
            box-sizing: border-box;
        }

        .preview img
        {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .thumbnails
        {
            float: right;
            width: 35%;
            padding: 10px;
            box-sizing: border-box;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            align-content: flex-start;
            max-height: 500px;
            overflow-y: auto;
        }

        .thumbnails img
        {
            width: 48%;
            cursor: pointer;
            border-radius: 8px;
            transition: opacity 0.3s ease;
        }

        .thumbnails img:hover
        {
            opacity: 0.6;
        }

        h1
        {
            text-align: center;
            margin-top: 80px;
        }

        /* Clearfix */
        .gallery-container::after
        {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>
<body style = "background-image: linear-gradient(rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.6)), url('asset/Begron.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; background-attachment: fixed; margin: 0; padding: 0; font-family: Arial, sans-serif; color: #212529;">
    <header>
        <div class = "header-left">
            <img src = "asset/Logo BPS.png" alt = "Logo Web" />
            <div class = "judulweb">BADAN PUSAT STATISTIK<br>PROVINSI KALIMANTAN TENGAH</div>
        </div>
        <nav class = "main-nav">
            <ul>
                <li><a href = "page09.php">Home</a></li>
                <li><a href = "page09A.php">Publikasi</a></li>
                <li><a href = "page09C.php">Tambah Publikasi</a></li>
                <li class = "active"><a href = "page06E.php">Galeri Kegiatan</a></li>
                <li><a href = "page10B.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1>Galeri Kegiatan BPS Kalimantan Tengah</h1>
        <div class = "gallery-container">
            <div class = "preview">
                <img id = "largeImage" src = "asset/Kegiatan 1.jpeg" alt = "Gambar Besar" />
            </div>
            <div class = "thumbnails">
                <img src = "asset/Kegiatan 1.jpeg" alt = "Kegiatan 1" />
                <img src = "asset/Kegiatan 2.jpeg" alt = "Kegiatan 2" />
                <img src = "asset/Kegiatan 3.jpeg" alt = "Kegiatan 3" />
                <img src = "asset/Kegiatan 4.jpeg" alt = "Kegiatan 4" />
                <img src = "asset/Kegiatan 5.jpeg" alt = "Kegiatan 5" />
                <img src = "asset/Kegiatan 6.jpeg" alt = "Kegiatan 6" />
            </div>
        </div>
    </main>
    <hr />
    <footer>
        <p>Copyright © 2025 Politeknik Statistika STIS</p>
        <p>Created by Ferdian Saputra (<a href = "mailto:222313086@stis.ac.id">222313086@stis.ac.id</a>)</p>
    </footer>
    <script>
        document.addEventListener('DOMContentLoaded', ()  =>
        {
            const largeImage = document.getElementById('largeImage');
            document.querySelectorAll('.thumbnails img').forEach(img  =>
            {
                img.addEventListener('click', ()  =>
                {
                    largeImage.src = img.src;
                    largeImage.alt = img.alt;
                });
            });
        });
    </script>
</body>
</html>