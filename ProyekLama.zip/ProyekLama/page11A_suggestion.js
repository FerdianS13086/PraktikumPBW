function showHint(str)
{
    if (str.length == 0)
        {
        document.getElementById("txtHint").innerHTML = "";
        return;
    }
    var xhttp = new XMLHttpRequest();
    //Code 4b
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
            {
            var data = JSON.parse(this.responseText);
            var hints = "";
            for (var i = 0; i < data.length; i++)
                {
                if (i > 0)
                    {
                    hints += ", ";
                }
                hints += data[i].judul;
            }
            document.getElementById("txtHint").innerHTML = hints;
        }
    };
    xhttp.open("GET", "page11A_gethint.php?keyword = " + encodeURIComponent(str), true);
    xhttp.send();
}