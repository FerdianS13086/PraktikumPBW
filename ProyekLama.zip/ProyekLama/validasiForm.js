// Validation script for formTambahPublikasi in page06C.html
// Validates inputs and displays error messages below each input field in real-time and on form submission

document.addEventListener('DOMContentLoaded', () =>
    {
    const form = document.forms['formTambahPublikasi'];

    const errorNo = document.getElementById('errorNo');
    const errorJudul = document.getElementById('errorJudul');
    const errorTanggalRilis = document.getElementById('errorTanggalRilis');
    const errorSampul = document.getElementById('errorSampul');

    const noInput = form['no'];
    const judulInput = form['judul'];
    const tanggalRilisInput = form['tanggal_rilis'];
    const sampulInput = form['sampul'];

    noInput.addEventListener('input', () =>
        {
        const value = noInput.value.trim();
        if (value === '')
            {
            errorNo.textContent = 'Nomor tidak boleh kosong.';
        } else if (!/^\d+$/.test(value))
            {
            errorNo.textContent = 'Masukkan nomor dalam angka.';
        } else if (Number(value) < 1)
            {
            errorNo.textContent = 'Nomor harus lebih dari 0.';
        } else {
            errorNo.textContent = '';
        }
    });

    judulInput.addEventListener('input', () =>
        {
        const value = judulInput.value.trim();
        if (value === '')
            {
            errorJudul.textContent = 'Judul tidak boleh kosong.';
        } else if (!/^[a-zA-Z0-9 :\-]+$/.test(value))
            {
            errorJudul.textContent = 'Terdapat karakter yang tidak valid pada judul.';
        } else
        {
            errorJudul.textContent = '';
        }
    });

    tanggalRilisInput.addEventListener('change', () =>
        {
        const value = tanggalRilisInput.value;
        if (value === '')
            {
            errorTanggalRilis.textContent = 'Tanggal rilis tidak boleh kosong.';
        } else
        {
            const today = new Date();
            const inputDate = new Date(value);
            today.setHours(0,0,0,0);
            inputDate.setHours(0,0,0,0);
            if (inputDate.getTime() > today.getTime())
                {
                errorTanggalRilis.textContent = 'Tanggal rilis tidak boleh melebihi hari ini.';
            } else
            {
                errorTanggalRilis.textContent = '';
            }
        }
    });

    sampulInput.addEventListener('change', () =>
        {
        const value = sampulInput.value;
        if (value === '')
            {
            errorSampul.textContent = 'Sampul harus dipilih.';
        } else
        {
            const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
            if (!allowedExtensions.exec(value))
                {
                errorSampul.textContent = 'Sampul harus berupa file gambar (jpg, jpeg, png, gif).';
            } else
            {
                errorSampul.textContent = '';
            }
        }
    });
});

function validate06C()
{
    const form = document.forms['formTambahPublikasi'];

    const errorNo = document.getElementById('errorNo');
    const errorJudul = document.getElementById('errorJudul');
    const errorTanggalRilis = document.getElementById('errorTanggalRilis');
    const errorSampul = document.getElementById('errorSampul');

    errorNo.textContent = '';
    errorJudul.textContent = '';
    errorTanggalRilis.textContent = '';
    errorSampul.textContent = '';

    const no = form['no'].value.trim();
    const judul = form['judul'].value.trim();
    const tanggalRilis = form['tanggal_rilis'].value;
    const sampul = form['sampul'].value;

    let valid = true;

    if (no === '' || !/^\d+$/.test(no) || Number(no) < 1)
        {
        errorNo.textContent = 'Nomor harus berupa angka lebih dari 0.';
        valid = false;
    }

    if (judul === '' || !/^[a-zA-Z0-9 :\-]+$/.test(judul))
        {
        errorJudul.textContent = 'Judul tidak boleh kosong dan hanya boleh mengandung huruf, angka, spasi, titik dua, dan tanda hubung.';
        valid = false;
    }

    if (tanggalRilis === '')
        {
        errorTanggalRilis.textContent = 'Tanggal rilis tidak boleh kosong.';
        valid = false;
    } else
    {
        const today = new Date();
        const inputDate = new Date(tanggalRilis);
        today.setHours(0,0,0,0);
        inputDate.setHours(0,0,0,0);
        if (inputDate.getTime() > today.getTime())
            {
            errorTanggalRilis.textContent = 'Tanggal rilis tidak boleh melebihi hari ini.';
            valid = false;
        }
    }

    if (sampul === '')
        {
        errorSampul.textContent = 'Sampul harus dipilih.';
        valid = false;
    } else
    {
        const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
        if (!allowedExtensions.exec(sampul))
            {
            errorSampul.textContent = 'Sampul harus berupa file gambar (jpg, jpeg, png, gif).';
            valid = false;
        }
    }

    return valid;
}