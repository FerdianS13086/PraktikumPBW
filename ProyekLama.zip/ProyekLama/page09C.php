<?php
session_start();
if (!isset($_SESSION['username']))
{
    header("Location: page10A.php");
    exit();
}
include 'dbconn.php';
?>

<!DOCTYPE html>
<html lang = "id">
<head>
    <meta charset = "UTF-8"/>
    <meta name = "viewport" content = "width = device-width, initial-scale = 1"/>
    <title>Tambah Publikasi BPS Kalimantan Tengah</title>
    <link rel = "stylesheet" href = "myCSS.css"/>
    <script src = "validasiForm.js"></script>
</head>
<body style = "background-image: linear-gradient(rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.6)), url('asset/Begron.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; background-attachment: fixed; margin: 0; padding: 0; font-family: Arial, sans-serif; color: #212529;">
    <header>
        <div class = "header-left">
            <img src = "asset/Logo BPS.png" alt = "Logo Web"/>
            <div class = "judulweb">BADAN PUSAT STATISTIK<br>PROVINSI KALIMANTAN TENGAH</div>
        </div>
        <nav class = "main-nav">
            <ul>
                <li><a href = "page09.php">Home</a></li>
                <li><a href = "page09A.php">Publikasi</a></li>
                <li class = "active"><a href = "page09C.php">Tambah Publikasi</a></li>
                <li><a href = "page06E.php">Galeri Kegiatan</a></li>
                <li><a href = "page10B.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1 style = "text-align: center;">Tambah Publikasi BPS Provinsi Kalimantan Tengah</h1>
        <p id = "pesanError" class = "error-message" style = "display: none;"></p>
        <form name = "formTambahPublikasi" onSubmit = "return validate()" action = "page09C_action.php" method = "post" enctype = "multipart/form-data">
            <label for = "no">No</label>
            <input type = "number" id = "no" name = "no" min = "1" required/>
            <p id = "errorNo" class = "error-message"></p>

            <label for = "judul">Judul</label>
            <input type = "text" id = "judul" name = "judul" required/>
            <p id = "errorJudul" class = "error-message"></p>

            <label for = "tanggal_rilis">Tanggal Rilis</label>
            <input type = "date" id = "tanggal_rilis" name = "tanggal_rilis" required/>
            <p id = "errorTanggalRilis" class = "error-message"></p>

            <label for = "sampul">Sampul</label>
            <input type = "file" id = "sampul" name = "sampul" accept = "image/*" required/>
            <p id = "errorSampul" class = "error-message"></p>

            <div>
                <button type = "submit">Tambah</button>
            </div>
        </form>
    </main>
    <hr/>
    <footer>
        <p>Copyright © 2025 Politeknik Statistika STIS</p>
        <p>Created by Ferdian Saputra (<a href = "mailto:222313086@stis.ac.id">222313086@stis.ac.id</a>)</p>
    </footer>
</body>
</html>