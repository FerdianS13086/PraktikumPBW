<?php
include 'dbconn.php';
try
{
    $keyword = $_GET["keyword"];
    $sql = "SELECT judul FROM publikasi WHERE judul LIKE :keyword";
    $stmt = $pdo -> prepare($sql);
    $stmt -> execute([':keyword' => "%$keyword%"]);
    $results = $stmt -> fetchAll(PDO::FETCH_ASSOC);

    // lookup all hints if query result is not empty
    if ($results)
    {
        echo json_encode($results);
    } else
    {
        // Output "no suggestion" if no hint was found or output correct values
        $response[] = array('judul' => 'no suggestion');
        echo json_encode($response);
    }
    $pdo = NULL;
}
catch (PDOException $e)
{
    exit("PDO Error: ".$e -> getMessage()."<br>");
}
?>