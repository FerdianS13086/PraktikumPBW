<?php
session_start();

include 'dbconn.php';

try
{
    // ambil username dan password dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // select row pada tabel user dimana username adalah username yang diinputkan pada form login
    $sql = "SELECT * FROM user WHERE username = :username";
    $stmt = $pdo -> prepare($sql);
    $stmt -> execute([':username' => $username]);
    $user = $stmt -> fetch(PDO::FETCH_ASSOC);

    if (!$user)
    {
        echo "<script>alert('Username/Password Tidak Ditemukan'); window.location.href = 'page10A.php';</script>";
        exit();
    }

    // cek password
    if ($user['password'] === $password)
    {
        $_SESSION['username'] = $username;
        header("Location: page09.php");
        exit();
    } else
    {
        echo "<script>alert('Username/Password salah'); window.location.href = 'page10A.php';</script>";
        exit();
    }

} catch (PDOException $e)
{
    echo "Koneksi gagal:" . $e -> getMessage();
}