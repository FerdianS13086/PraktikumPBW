<?php
session_start();
session_destroy();
header("Location: page10A.php");
exit();