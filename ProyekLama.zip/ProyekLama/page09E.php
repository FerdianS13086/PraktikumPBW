<?php
// page09E.php - Edit form for publikasi
// Get data from GET parameters
$no = isset($_GET['no']) ? $_GET['no'] : '';
$judul = isset($_GET['judul']) ? $_GET['judul'] : '';
$tanggal_rilis = isset($_GET['tanggal_rilis']) ? $_GET['tanggal_rilis'] : '';
$sampul = isset($_GET['sampul']) ? $_GET['sampul'] : '';
?>

<!DOCTYPE html>
<html lang = "id">
<head>
    <meta charset = "UTF-8" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1" />
    <title>Edit Publikasi BPS Kalimantan Tengah</title>
    <link rel = "stylesheet" href = "myCSS.css" />
    <script src = "validasiForm.js"></script>
</head>
<body style = "background-image: linear-gradient(rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.6)), url('asset/Begron.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; background-attachment: fixed; margin: 0; padding: 0; font-family: Arial, sans-serif; color: #212529;">
    <header>
        <div class = "header-left">
            <img src = "asset/Logo BPS.png" alt = "Logo Web" />
            <div class = "judulweb">BADAN PUSAT STATISTIK<br>PROVINSI KALIMANTAN TENGAH</div>
        </div>
        <nav class = "main-nav">
            <ul>
                <li><a href = "page09.php">Home</a></li>
                <li><a href = "page09A.php">Publikasi</a></li>
                <li class = "active"><a href = "page09E.php">Edit Publikasi</a></li>
                <li><a href = "page06E.php">Galeri Kegiatan</a></li>
                <li><a href = "page10B.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1 style = "text-align: center;">Edit Publikasi BPS Provinsi Kalimantan Tengah</h1>
        <p id = "pesanError" class = "error-message" style = "display: none;"></p>
        <form name = "formEditPublikasi" onsubmit = "return validate()" action = "page09E_action.php" method = "post" enctype = "multipart/form-data">
            <label for = "no">No</label>
            <input type = "number" id = "no" name = "no" value = "<?= htmlspecialchars($no) ?>" readonly style = "background-color: #e9ecef;" required />
            <p id = "errorNo" class = "error-message"></p>

            <label for = "judul">Judul</label>
            <input type = "text" id = "judul" name = "judul" value = "<?=  htmlspecialchars($judul) ?>" required />
            <p id = "errorJudul" class = "error-message"></p>

            <label for = "tanggal_rilis">Tanggal Rilis</label>
            <input type = "date" id = "tanggal_rilis" name = "tanggal_rilis" value = "<?=  htmlspecialchars($tanggal_rilis) ?>" required />
            <p id = "errorTanggalRilis" class = "error-message"></p>

            <label for = "sampul_lama">Sampul Lama:</label><br />
            <img src = "asset/<?=  htmlspecialchars($sampul) ?>" alt = "Sampul Lama" width = "70px" /><br /><br />

            <label for = "sampul_baru" style = "padding-right:10px;">Sampul Baru:</label>
            <input type = "file" id = "sampul_baru" name = "sampul_baru" accept = "image/*" />
            <p id = "errorSampul" class = "error-message"></p>

            <div>
                <button type = "submit">Ubah</button>
            </div>
        </form>
    </main>
    <hr />
    <footer>
        <p>Copyright © 2025 Politeknik Statistika STIS</p>
        <p>Created by Ferdian Saputra (<a href = "mailto:222313086@stis.ac.id">222313086@stis.ac.id</a>)</p>
    </footer>
</body>
</html>