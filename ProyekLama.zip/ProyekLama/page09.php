<?php
session_start();
if (!isset($_SESSION['username']))
{
    header("Location: page10A.php");
    exit();
}
include 'dbconn.php';

try
{
    $sql = "SELECT * FROM publikasi ORDER BY no ASC LIMIT 2";
    $stmt = $pdo -> query($sql);
    $publikasiList = $stmt -> fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e)
{
    exit('Gagal mengambil data publikasi: ' . $e -> getMessage());
}
?>

<!DOCTYPE html>
<html lang = "id">
<head>
    <meta charset = "UTF-8"/>
    <meta name = "viewport" content = "width = device-width, initial-scale = 1"/>
    <title>Home - BPS Kalimantan Tengah</title>
    <link rel = "stylesheet" href = "myCSS.css"/>
    <style>
        body
        {
            background-image: linear-gradient(rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.6)), url('asset/Begron.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            color: #212529;
        }

        .banner
        {
            background-image: url('banner-bps.jpg');
            background-size: cover;
            background-position: center;
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
            margin-bottom: 30px;
            border-radius: 8px;
        }

        .content-section
        {
            width: 75%;
            margin: 0 auto 40px auto;
        }

        .content-section h2
        {
            border-bottom: 3px solid #007bff;
            padding-bottom: 8px;
            margin-bottom: 20px;
            color: #007bff;
        }

        .news-list, .stats-list
        {
            list-style: none;
            padding-left: 0;
        }

        .news-list li, .stats-list li
        {
            margin-bottom: 10px;
            font-size: 1.1rem;
        }

        .news-list li a
        {
            color: #0056b3;
            text-decoration: none;
        }

        .news-list li a:hover
        {
            text-decoration: underline;
        }

        footer
        {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            font-size: 0.9rem;
            line-height: 1.4;
        }

        .footer-left
        {
            display: flex;
            align-items: center;
            text-align: left;
            gap: 10px;
        }

        .footer-left a
        {
            color: inherit;
            text-decoration: none;
        }

        .footer-center
        {
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <div class = "header-left">
            <img src = "asset/Logo BPS.png" alt = "Logo Web"/>
            <div class = "judulweb">BADAN PUSAT STATISTIK<br>PROVINSI KALIMANTAN TENGAH</div>
        </div>
        <nav class = "main-nav">
            <ul>
                <li class = "active"><a href = "page09.php">Home</a></li>
                <li><a href = "page09A.php">Publikasi</a></li>
                <li><a href = "page09C.php">Tambah Publikasi</a></li>
                <li><a href = "page06E.php">Galeri Kegiatan</a></li>
                <li><a href = "page10B.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class = "banner" style = "text-align: center">
            Badan Pusat Statistik<br>Provinsi Kalimantan Tengah
        </div>
        <div class = "content-section">
            <h2>Publikasi</h2>
            <ul class = "news-list">
                <?php foreach ($publikasiList as $publikasi): ?>
                <li><a href = "#"><?php echo htmlspecialchars($publikasi['judul']); ?></a></li>
                <?php endforeach; ?>
                <li><a href = "page09A.php">Cari Publikasi Lain</a></li>
            </ul>
        </div>
        <div class = "content-section">
            <h2>Statistik Unggulan</h2>
            <ul class = "stats-list">
                <li>Pendapatan per Kapita ADHB: 79.317,70 ribu rupiah (2024)</li>
                <li>Neraca Perdagangan: 223,51 juta US$ (April 2025)</li>
                <li>Nilai Tukar Petani: 134,29 (Mei 2025)</li>
                <li>Indeks Pembangunan Manusia: 74,28 (2024)</li>
                <li>Inflasi: -0,53% (Mei 2025 m-to-m)</li>
            </ul>
        </div>
        <div class = "content-section">
            <h2>Tentang BPS</h2>
            <p>Badan Pusat Statistik (BPS) Provinsi Kalimantan Tengah adalah lembaga pemerintah yang bertugas menyediakan data statistik resmi yang akurat dan terpercaya untuk mendukung pembangunan daerah dan nasional.
            Kami berkomitmen untuk memberikan informasi statistik yang transparan dan mudah diakses oleh masyarakat, pemerintah, dan pelaku usaha.</p>
        </div>
    </main>
    <hr/>
    <footer>
        <div class = "footer-left">
            <img src = "asset/Lokasi.png" alt = "Lokasi" style = "height: 40px;">
            <a href = "https://maps.app.goo.gl/UCyNcUQycu3YxZXo6" target = "_blank">
                BPS Provinsi Kalimantan Tengah<br>
                Jl. Kapten Piere Tendean No. 6,<br>
                Kel. Palangka, Kec. Jekan Raya,<br>
                Palangka Raya, Kalimantan Tengah<br>
            </a>
        </div>
        <div class = "footer-center" style = "display: flex; align-items: center; gap: 10px;">
            <p>Copyright © 2025 Politeknik Statistika STIS<br>Created by Ferdian Saputra (<a href = "mailto:222313086@stis.ac.id">222313086@stis.ac.id</a>)</p>
        </div>
        <div style = "display: flex; align-items: center; gap: 10px;">
            <img src = "asset/Logo STIS.png" alt = "Logo STIS" style = "height: 40px;">
            <span>Politeknik Statistika STIS</span>
        </div>
    </footer>
</body>
</html>