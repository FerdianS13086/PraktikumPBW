<?php

include 'dbconn.php';

try
{
    $no = $_POST['no'];
    $judul = $_POST['judul'];
    $tanggal_rilis = $_POST['tanggal_rilis'];

    $namaFile = '';

    // ambil data file
    if (isset($_FILES['sampul']) && $_FILES['sampul']['error'] === UPLOAD_ERR_OK)
    {
        $namaFile = $_FILES['sampul']['name'];
        $lokasiSementara = $_FILES['sampul']['tmp_name'];

        // tentukan lokasi file akan dipindahkan
        $dirUpload = '';

        if (!is_dir($dirUpload))
        {
            mkdir($dirUpload, 0755, true);
        }

        if (!move_uploaded_file($lokasiSementara, $dirUpload . $namaFile))
        {
            exit('Terjadi kesalahan saat mengupload file sampul.');
        }
    } else
    {
        exit('File sampul harus diupload.');
    }

    // Insert data into publikasi table
    $sql = "INSERT INTO publikasi (no, judul, tanggal_rilis, sampul) VALUES (:no, :judul, :tanggal_rilis, :sampul)";
    $stmt = $pdo -> prepare($sql);
    $stmt -> execute([
        ':no' => $no,
        ':judul' => $judul,
        ':tanggal_rilis' => $tanggal_rilis,
        ':sampul' => $namaFile
    ]);

    echo "
          <script>
              alert('Data Berhasil Ditambahkan');
              window.location.href = 'page09A.php';
          </script>
          ";

    $pdo = NULL;
} catch (PDOException $e)
{
    exit("PDO Error: " . $e -> getMessage() . "<br>");
}