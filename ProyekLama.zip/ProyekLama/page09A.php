<?php
session_start();
if (!isset($_SESSION['username']))
{
    header("Location: page10A.php");
    exit();
}
include 'dbconn.php';

try
{
    $sql = "SELECT * FROM publikasi ORDER BY no ASC";
    $stmt = $pdo -> query($sql);
    $publikasiList = $stmt -> fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e)
{
    exit('Gagal mengambil data publikasi: ' . $e -> getMessage());
}
?>

<!DOCTYPE html>
<html lang = "id">
<head>
    <meta charset = "UTF-8"/>
    <meta name = "viewport" content = "width = device-width, initial-scale = 1"/>
    <title>Daftar Publikasi BPS Kalimantan Tengah</title>
    <link rel = "stylesheet" href = "myCSS.css"/>
</head>
<body style = "background-image: linear-gradient(rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.6)), url('asset/Begron.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; background-attachment: fixed; margin: 0; padding: 0; font-family: Arial, sans-serif; color: #212529;">
    <header>
        <div class = "header-left">
            <img src = "asset/Logo BPS.png" alt = "Logo Web"/>
            <div class = "judulweb">BADAN PUSAT STATISTIK<br>PROVINSI KALIMANTAN TENGAH</div>
        </div>
        <nav class = "main-nav">
            <ul>
                <li><a href = "page09.php">Home</a></li>
                <li class = "active"><a href = "page09A.php">Publikasi</a></li>
                <li><a href = "page09C.php">Tambah Publikasi</a></li>
                <li><a href = "page06E.php">Galeri Kegiatan</a></li>
                <li><a href = "page10B.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1 style = "text-align: center;">Daftar Publikasi BPS Provinsi Kalimantan Tengah</h1>
        <form action = "">
            Cari Judul Publikasi<input type = "text" id = "txt1" onkeyup = "showHint(this.value); filterTable()">
            <br/>
            <span>Saran: <span id = "txtHint"></span></span>
        </form>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Tanggal Rilis</th>
                    <th>Sampul</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($publikasiList as $publikasi): ?>
                <tr>
                    <td><?php echo htmlspecialchars($publikasi['no']); ?></td>
                    <td><?php echo htmlspecialchars($publikasi['judul']); ?></td>
                    <td>
                        <?php
                        setlocale(LC_TIME, 'id_ID.UTF-8', 'Indonesian_indonesia.1252', 'Indonesian');
                        echo strftime('%d %B %Y', strtotime($publikasi['tanggal_rilis']));
                        ?>
                    </td>
                    <td><img class = "sampul" src = "asset/<?php echo htmlspecialchars($publikasi['sampul']); ?>" alt = "Sampul <?php echo htmlspecialchars($publikasi['no']); ?>" style = "max-width: 96px; height: auto; border-radius: 4px;"/></td>
                    <td>
                        <a href = "page09E.php?no = <?php echo urlencode($publikasi['no']); ?>&judul = <?php echo urlencode($publikasi['judul']); ?>&sampul = <?php echo urlencode($publikasi['sampul']); ?>"><img src = "asset/Edit.png" style = "width:32px;height:32px;"></a>
                        <a href = "page09F.php?no = <?php echo urlencode($publikasi['no']); ?>&sampul = <?php echo urlencode($publikasi['sampul']); ?>"><img src = "asset/Hapus.png" style = "width:32px;height:32px;"></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
    <hr/>
    <footer>
        <p>Copyright © 2025 Politeknik Statistika STIS</p>
        <p>Created by Ferdian Saputra (<a href = "mailto:222313086@stis.ac.id">222313086@stis.ac.id</a>)</p>
    </footer>
<script>
function filterTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("txt1");
    filter = input.value.toUpperCase();
    table = document.querySelector("table");
    tr = table.getElementsByTagName("tr");
    for (i = 1; i < tr.length; i++) { // skip header row
        td = tr[i].getElementsByTagName("td")[1]; // judul column
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}
</script>
<script src = "page11A_suggestion.js"></script>
</body>
</html>