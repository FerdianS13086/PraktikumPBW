<?php
session_start();
if (isset($_SESSION['username']))
{
    header("Location: page09A.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang = "id">
<head>
    <meta charset = "UTF-8" />
    <meta name = "viewport" content = "width = device-width, initial-scale = 1" />
    <title>Login BPS Kalimantan Tengah</title>
    <link rel = "stylesheet" href = "myCSS.css" />
</head>
<body style = "background-image: linear-gradient(rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.6)), url('asset/Begron.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat; background-attachment: fixed; margin: 0; padding: 0; font-family: Arial, sans-serif; color: #212529;">
    <header>
        <div class = "header-left">
            <img src = "asset/Logo BPS.png" alt = "Logo Web" />
            <div class = "judulweb">BADAN PUSAT STATISTIK<br>PROVINSI KALIMANTAN TENGAH</div>
        </div>
    </header>
    <main style = "margin: 20px; text-align: center">
        <h1>Login</h1>
        <form action = "page10A_action.php" method = "post">
            <table>
                <tr>
                    <td><label for = "username">Username:</label></td>
                    <td><input type = "text" id = "username" name = "username" required /></td>
                </tr>
                <tr>
                    <td><label for = "password">Password:</label></td>
                    <td><input type = "password" id = "password" name = "password" required /></td>
                </tr>
                <tr>
                    <td><input type = "submit" value = "Login" /></td>
                    <td></td>
                </tr>
            </table>
        </form>
    </main>
</body>
</html>