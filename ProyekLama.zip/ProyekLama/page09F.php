<?php

include 'dbconn.php';

try
{
    $no = $_GET['no'];
    $namaFile = $_GET['sampul'];

    // Delete the image file
    $filePath = '' . $namaFile;
    if (file_exists($filePath))
    {
        unlink($filePath);
    }

    // Delete the record from database
    $sql = "DELETE FROM publikasi WHERE no = :no";
    $stmt = $pdo -> prepare($sql);
    $stmt -> execute([':no' => $no]);

    echo "
        <script>
            alert('Data Berhasil Dihapus');
            window.location.href = 'page09A.php';
        </script>
    ";

    $pdo = NULL;
} catch (PDOException $e)
{
    exit("PDO Error: " . $e -> getMessage() . "<br>");
}